Examples
========


.. toctree::
   :maxdepth: 1

   demo.rst
   huber.rst
   lasso.rst
   least-squares.rst
   mpc.rst
   portfolio.rst
   svm.rst
