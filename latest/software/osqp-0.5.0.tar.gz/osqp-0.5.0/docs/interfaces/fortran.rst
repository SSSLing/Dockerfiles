.. _fortran_interface:


Fortran
========

The interface is still experimental.
You can find a demo of how it works in the `oxfordcontrol/osqp-fortran <https://github.com/oxfordcontrol/osqp-fortran/blob/master/demo/osqp_demo_fortran.F90>`_ repository.
