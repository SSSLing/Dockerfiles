# Pure Julia implementation of the QDLDL solver algorithm

File `QDLDL.jl` contains a pure julia implementation of the algorithm that might be useful for testing or prototyping purposes.
